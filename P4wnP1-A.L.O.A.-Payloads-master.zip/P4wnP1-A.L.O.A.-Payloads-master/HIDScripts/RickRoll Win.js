layout('us');
press("GUI r");
delay(500);
type("https://www.youtube.com/watch?v=dQw4w9WgXcQ")
press("ENTER");



