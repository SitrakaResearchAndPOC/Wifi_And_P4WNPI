// Opens Rick Astley - Never Gonna Give You Up Video on OSX
// You need to setup P4wnP1 USB Gadget Settings as HID keyboard 

layout("us");
delay(500)
press("WIN SPACE") 
delay(500) 
type("https://www.youtube.com/watch?v=dQw4w9WgXcQ\n")
delay(500)
press("ENTER")
