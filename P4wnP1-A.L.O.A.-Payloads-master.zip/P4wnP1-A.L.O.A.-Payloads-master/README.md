# P4wnP1-A.L.O.A. Payloads
Payloads for P4wnP1 A.L.O.A

* HID Scripts should be placed in ``` /usr/local/P4wnP1/HIDScripts ```
* Shell scripts should be places in ``` /usr/local/P4wnP1/scripts accessible ```
* Loot directory will be created in: ``` /usr/local/P4wnP1/www/loot ``` and is accessible via browser at: ``` http://172.XX.0.1:8000/loot/ ```

**You can find the usage and requirements information in the comments inside each file**
